<?php
// ~~ MAIN ADMIN DASHBOARD MODEL ~~ // <^^!>


function ai_mp_rp_manage_admin_menus_mod()
{
   add_menu_page('Reportings', 'Reportings', 'main_option','ai_mp_rp_settings', 'ai_mp_rp_sales_per_property_settings', AIMPRPATH."/img/icon.png");
   add_submenu_page('ai_mp_rp_settings', 'Sales Overview', 'Sales Per Property', 'manage_options','ai_mp_rp_sales_per_property_settings', 'ai_mp_rp_manage_sales_per_property_cont');
   add_submenu_page('ai_mp_rp_settings', 'Sales (equipment)', 'Sales (equipment)', 'manage_options','ai_mp_rp_sales_equipment_settings', 'ai_mp_rp_manage_sales_equipment_cont');	
   add_submenu_page('ai_mp_rp_settings', 'Sales (Catering)', 'Sales (Catering)', 'manage_options','ai_mp_rp_sales_catering_settings', 'ai_mp_rp_sales_catering_settings_cont');	
}

// FUNCTION TO MANAGE SALES PER PROPERTIES //

function ai_mp_rp_manage_sales_per_property_mod($args="")
{
	GLOBAL $wpdb;
	$action=json_decode(ai_mp_rp_check_isset_value($args,'action'))->value;
	$all_results=array();
	$results=array();
	$post_table=$wpdb->base_prefix."posts";	
	$post_meta_table=$wpdb->base_prefix."postmeta";
	
	if($action=="view" || $action=="filter")
	{
		$space_id=ai_mp_rp_check_request("space_id");	
		$property_id=ai_mp_rp_check_request("property_id");		
		$duration=ai_mp_rp_check_request("duration");		
		$date_range_from=ai_mp_rp_check_request("date_range_from");
		$date_range_to=ai_mp_rp_check_request("date_range_to");

		// CODE TO MANAGE FILTERS FOR SUB QUERY //
		
		$filters_sub_query_table="";
		$filters_sub_query="AND YEAR(p.post_date) = YEAR(CURDATE())";
		
		if($action=="filter")
		{
			$filters_sub_query_data=ai_mp_rp_manage_filters_sub_query(array("action"=>"sales"));
			$filters_sub_query_table=$filters_sub_query_data["table"];
			$filters_sub_query=$filters_sub_query_data["sub_query"];		
			
		}
		
		
		// CASE FOR DURATIONS //

		if($duration=="7days" || $duration=="1month")
		{
			$main_query="SELECT DATE(p.post_date) as date, SUM(pm.meta_value) as total FROM $post_table p, $post_meta_table pm $filters_sub_query_table WHERE p.post_type='bookings' AND p.ID=pm.post_id AND pm.meta_key='total' AND post_status='publish' $filters_sub_query GROUP BY YEAR(p.post_date), MONTH(p.post_date)";
			//echo $main_query;
		}
		else if(ai_mp_rp_check_empty_value($date_range_from)==false || ai_mp_rp_check_empty_value($date_range_to)==false)
		{
			$main_query="SELECT DATE(p.post_date) as date, SUM(pm.meta_value) as total FROM $post_table p, $post_meta_table pm $filters_sub_query_table WHERE p.post_type='bookings' AND p.ID=pm.post_id AND pm.meta_key='total' AND post_status='publish' $filters_sub_query GROUP BY DATE(p.post_date)";
			//echo $main_query;			
		}
		else
		{
			$main_query="SELECT 
								IFNULL(ROUND(SUM(if(MONTH(p.post_date) = 1, pm.meta_value,0)), 2),0.00) as 'January',
								IFNULL(ROUND(SUM(if(MONTH(p.post_date) = 2, pm.meta_value,0)), 2),0.00) as 'February',
								IFNULL(ROUND(SUM(if(MONTH(p.post_date) = 3, pm.meta_value,0)), 2),0.00) as 'March',
								IFNULL(ROUND(SUM(if(MONTH(p.post_date) = 4, pm.meta_value,0)), 2),0.00) as 'April',
								IFNULL(ROUND(SUM(if(MONTH(p.post_date) = 5, pm.meta_value,0)), 2),0.00) as 'May',
								IFNULL(ROUND(SUM(if(MONTH(p.post_date) = 6, pm.meta_value,0)), 2),0.00) as 'June',
								IFNULL(ROUND(SUM(if(MONTH(p.post_date) = 7, pm.meta_value,0)), 2),0.00) as 'July',
								IFNULL(ROUND(SUM(if(MONTH(p.post_date) = 8, pm.meta_value,0)), 2),0.00) as 'August',
								IFNULL(ROUND(SUM(if(MONTH(p.post_date) = 9, pm.meta_value,0)), 2),0.00) as 'September',
								IFNULL(ROUND(SUM(if(MONTH(p.post_date) = 10, pm.meta_value,0)), 2),0.00) as 'October',
								IFNULL(ROUND(SUM(if(MONTH(p.post_date) = 11, pm.meta_value,0)), 2),0.00) as 'November',
								IFNULL(ROUND(SUM(if(MONTH(p.post_date) = 12, pm.meta_value,0)), 2),0.00) as 'December'
							FROM $post_table p, $post_meta_table pm $filters_sub_query_table WHERE p.post_type='bookings' AND p.ID=pm.post_id AND pm.meta_key='total' AND post_status='publish' $filters_sub_query";
			//echo $main_query;				
		}
		
		
		$sales_data= $wpdb->get_results($main_query);	
		
					$all_results=array();
					$total_sales_data=array();
					
					// CASE TO GET ALL DATES IN DURATION // ~ STARTS 
					
						$dates_for_labels=($duration=="1month") ? ai_mp_rp_get_all_dates_in_current_month(date("Y"),date("m"),"Y-m-d") : ai_mp_rp_get_all_dates_of_past_7_days();

					// CASE TO GET ALL DATES IN DURATION // ~ ENDS
					
									// ~ NEW CASE //

					// CASE TO GET DATES BETWEEN TWO RANGES // ~ STARTS 	
																		
						$dates_for_labels=(ai_mp_rp_check_empty_value($date_range_from)==false || ai_mp_rp_check_empty_value($date_range_to)==false) ? ai_mp_rp_get_all_dates_between_ranges($date_range_from,$date_range_to) : $dates_for_labels;

					// CASE TO GET DATES BETWEEN TWO RANGES // ~ ENDS	

					// LOOP TO CREATE DEFAULT RESULTS FOR DATE //
					
					foreach($dates_for_labels as $single_date)
					{
						$all_results[$single_date]=0.00;
					}
				
				
		if($wpdb->num_rows > 0)
		{		
	
				if(($duration=="7days" || $duration=="1month") || (ai_mp_rp_check_empty_value($date_range_from)==false || ai_mp_rp_check_empty_value($date_range_to)==false))
				{
					
					// LOOP TO CREATE FINAL ARRAY FOR RESULTS //
					
					foreach ($sales_data as $single_sale)
					{
						$all_results[$single_sale->date]=$single_sale->total;
					}
					
					$total_sales_data[]=$all_results;
					
					$results['data']=$total_sales_data;
					
				}			
				else
				{
					$results['data']=$sales_data;				
				}
	
				$results['status']="success";

			
		}
		else
		{
			$results['status']="error";
			$total_sales_data[]=$all_results;
			$results['data']=$total_sales_data;		
		}
		

	}
	
	return json_encode($results);	
	
}

// FUNCTION TO MANAGE SALES EXTRAS //

function ai_mp_rp_manage_sales_extra_mod($args="")
{
	GLOBAL $wpdb;
	$action=json_decode(ai_mp_rp_check_isset_value($args,'action'))->value;
	$module=json_decode(ai_mp_rp_check_isset_value($args,'module'))->value;
	$all_results=array();
	$results=array();
	$booking_items_table=$wpdb->base_prefix."ai_mp_bookings_items";
	$post_table=$wpdb->base_prefix."posts";
	$post_meta_table=$wpdb->base_prefix."postmeta";
	if($module=="catering" || $module=="equipments")
	{
		if($action=="view" || $action=="filter")
		{
			$type=($module=="equipments") ? 1 : 0;
			$space_id=ai_mp_rp_check_request("space_id");	
			$property_id=ai_mp_rp_check_request("property_id");		
			$duration=ai_mp_rp_check_request("duration");		
			$date_range_from=ai_mp_rp_check_request("date_range_from");
			$date_range_to=ai_mp_rp_check_request("date_range_to");

			// CODE TO MANAGE FILTERS FOR SUB QUERY //
			
			$filters_sub_query_table="";
			$filters_sub_query="AND YEAR(p.post_date) = YEAR(CURDATE())";
			
			if($action=="filter")
			{
				$filters_sub_query_data=ai_mp_rp_manage_filters_sub_query(array("action"=>"sales_meta"));
				$filters_sub_query_table=$filters_sub_query_data["table"];
				$filters_sub_query=$filters_sub_query_data["sub_query"];		
				
			}
			
			
			// CASE FOR DURATIONS //

			if($duration=="7days" || $duration=="1month")
			{
				$main_query="SELECT DATE(FROM_UNIXTIME(bm.timestamp)) as date, SUM(bm.total_price) as total FROM wp_ai_mp_bookings_items bm,$post_table p $filters_sub_query_table WHERE p.post_type='bookings' AND p.ID=bm.post_id AND p.post_status='publish' AND bm.type = '$type' $filters_sub_query GROUP BY YEAR(FROM_UNIXTIME(bm.timestamp)), MONTH(FROM_UNIXTIME(bm.timestamp))";
				//SELECT DATE(p.post_date) as date, SUM(pm.meta_value) as total FROM $post_table p, $post_meta_table pm $filters_sub_query_table WHERE p.post_type='bookings' AND p.ID=pm.post_id AND pm.meta_key='total' AND post_status='publish' $filters_sub_query GROUP BY YEAR(p.post_date), MONTH(p.post_date)
				//echo $main_query;
			}
			else if(ai_mp_rp_check_empty_value($date_range_from)==false || ai_mp_rp_check_empty_value($date_range_to)==false)
			{
				$main_query="SELECT DATE(FROM_UNIXTIME(bm.timestamp)) as date, SUM(bm.total_price) as total FROM wp_ai_mp_bookings_items bm,$post_table p $filters_sub_query_table WHERE p.post_type='bookings' AND p.ID=bm.post_id AND p.post_status='publish' AND type = '$type' $filters_sub_query GROUP BY DATE(FROM_UNIXTIME(bm.timestamp))";
				//SELECT DATE(p.post_date) as date, SUM(pm.meta_value) as total FROM $post_table p, $post_meta_table pm $filters_sub_query_table WHERE p.post_type='bookings' AND p.ID=pm.post_id AND pm.meta_key='total' AND post_status='publish' $filters_sub_query GROUP BY DATE(p.post_date)
				//echo $main_query;			
			}
			else
			{
				$main_query="SELECT 
									SUM(if(MONTH(FROM_UNIXTIME(timestamp)) = 1, total_price,0)) as 'January',
									SUM(if(MONTH(FROM_UNIXTIME(timestamp)) = 2, total_price,0)) as 'February',
									SUM(if(MONTH(FROM_UNIXTIME(timestamp)) = 3, total_price,0)) as 'March',
									SUM(if(MONTH(FROM_UNIXTIME(timestamp)) = 4, total_price,0)) as 'April',
									SUM(if(MONTH(FROM_UNIXTIME(timestamp)) = 5, total_price,0)) as 'May',
									SUM(if(MONTH(FROM_UNIXTIME(timestamp)) = 6, total_price,0)) as 'June',
									SUM(if(MONTH(FROM_UNIXTIME(timestamp)) = 7, total_price,0)) as 'July',
									SUM(if(MONTH(FROM_UNIXTIME(timestamp)) = 8, total_price,0)) as 'August',
									SUM(if(MONTH(FROM_UNIXTIME(timestamp)) = 9, total_price,0)) as 'September',
									SUM(if(MONTH(FROM_UNIXTIME(timestamp)) = 10, total_price,0)) as 'October',
									SUM(if(MONTH(FROM_UNIXTIME(timestamp)) = 11, total_price,0)) as 'November',
									SUM(if(MONTH(FROM_UNIXTIME(timestamp)) = 12, total_price,0)) as 'December'
								FROM wp_ai_mp_bookings_items bm,$post_table p $filters_sub_query_table
								WHERE YEAR(FROM_UNIXTIME(timestamp)) = YEAR(CURDATE()) 
								  AND type = '$type' AND p.post_type='bookings' AND p.ID=bm.post_id AND p.post_status='publish' $filters_sub_query";
								  
				//echo $main_query;				  
			}
		//	echo $main_query;	
			$sales_data= $wpdb->get_results($main_query);	
		
					$all_results=array();
					$total_sales_data=array();
					
					// CASE TO GET ALL DATES IN DURATION // ~ STARTS 
					
						$dates_for_labels=($duration=="1month") ? ai_mp_rp_get_all_dates_in_current_month(date("Y"),date("m"),"Y-m-d") : ai_mp_rp_get_all_dates_of_past_7_days();

					// CASE TO GET ALL DATES IN DURATION // ~ ENDS
					
									// ~ NEW CASE //

					// CASE TO GET DATES BETWEEN TWO RANGES // ~ STARTS 	
																		
						$dates_for_labels=(ai_mp_rp_check_empty_value($date_range_from)==false || ai_mp_rp_check_empty_value($date_range_to)==false) ? ai_mp_rp_get_all_dates_between_ranges($date_range_from,$date_range_to) : $dates_for_labels;

					// CASE TO GET DATES BETWEEN TWO RANGES // ~ ENDS	

					// LOOP TO CREATE DEFAULT RESULTS FOR DATE //
					
					foreach($dates_for_labels as $single_date)
					{
						$all_results[$single_date]=0.00;
					}
			if($wpdb->num_rows > 0)
			{					
				if($duration=="7days" || $duration=="1month")
				{
					
					// LOOP TO CREATE FINAL ARRAY FOR RESULTS //
					
					foreach ($sales_data as $single_sale)
					{
						$all_results[$single_sale->date]=$single_sale->total;
					}
					
					$total_sales_data[]=$all_results;
					
					$results['data']=$total_sales_data;
					
				}
				else
				{
					$results['data']=$sales_data;				
				}
	
				$results['status']="success";
				
			}
			else
			{
				$results['status']="error";
				$total_sales_data[]=$all_results;
				$results['data']=$total_sales_data;			
			}


		}
	}


	return json_encode($results);	
	
}