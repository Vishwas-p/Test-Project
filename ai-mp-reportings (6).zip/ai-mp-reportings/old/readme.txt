﻿=== Plugin Name ===
A plugin for MP Reports
Contributors: paramveer singh
Tags: WordPress.com, buddypress
Requires at least: 4.4
Tested up to: 4.8
Stable tag: 1.0.22
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin which helps in generating reports for bookings, catering and equipment sales.

== Description ==

A plugin which helps in generating reports for bookings, catering and equipment sales.


== Installation ==


1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.




== Changelog ==

= 1.0.0 - Release date: NOW
* New! - Initial Release.