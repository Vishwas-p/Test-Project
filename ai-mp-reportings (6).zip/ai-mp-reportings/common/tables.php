<?php
if(!class_exists('WP_List_Table')){
    require_once( ABSPATH.'wp-admin/includes/class-wp-list-table.php' );
}

// CLASS TO EXTEND THE DEFAULT WORDPRESS TABLE  LIST //

class ai_mp_rp_extend_default_table extends WP_List_Table
{
    public $main_data;
    public $module;
	public $module_args;
	
	// FUNCTION TO PROCESS THE TABLE DATA //
	
    public static function ai_mp_rp_process_table_data($module_args,$page_number = 1)
    {
        global $wpdb;
        $main_data = array();
		
		$module = json_decode(ai_mp_rp_check_isset_value($module_args, 'module'))->value;
		$data_selection=json_decode(ai_mp_rp_check_isset_value($module_args, 'data_selection'))->value;
		
		$per_page = json_decode(ai_mp_rp_check_isset_value($module_args, 'pagination'))->value;
		$table_name = json_decode(ai_mp_rp_check_isset_value($data_selection, 'table'))->value;
		$order = json_decode(ai_mp_rp_check_isset_value($data_selection, 'order'))->value;
		$order_by = json_decode(ai_mp_rp_check_isset_value($data_selection, 'order_by'))->value;
		$fields = json_decode(ai_mp_rp_check_isset_value($data_selection, 'fields'))->value;
		$table = $wpdb->base_prefix.$table_name;
        $result    = "";
        $sql = "SELECT $fields FROM $table";
		$sql .= " ORDER BY $order_by $order";
		//$sql .= !empty($_REQUEST['order']) ? ' ' . esc_sql($_REQUEST['order']) : ' ASC';
        if (!empty($per_page)) {
            $sql .= " LIMIT $per_page";
            $sql .= ' OFFSET ' . ($page_number - 1) * $per_page;
        }

        $result = $wpdb->get_results($sql,'ARRAY_A');
		$count =1;
		
		if($wpdb->num_rows > 0)
		{
			$main_data = $result;
	
		}
		
        return $main_data;
    }

	// FUNCTION TO COUNT RECORDS FROM TABLE //
	
	public static function count_total_records($module_args) 
	{
		
		global $wpdb;
	  
        $main_data = array();
		$module = json_decode(ai_mp_rp_check_isset_value($module_args, 'module'))->value;
		$data_selection=json_decode(ai_mp_rp_check_isset_value($module_args, 'data_selection'))->value;
		$table_name = json_decode(ai_mp_rp_check_isset_value($data_selection, 'table'))->value;		
		$table = $wpdb->base_prefix.$table_name;		
		$module = json_decode(ai_mp_rp_check_isset_value($module_args, 'module'))->value;
		$data_selection=json_decode(ai_mp_rp_check_isset_value($module_args, 'data_selection'))->value;
		$per_page = json_decode(ai_mp_rp_check_isset_value($module_args, 'pagination'))->value;
		$table_name = json_decode(ai_mp_rp_check_isset_value($data_selection, 'table'))->value;	  

	  $sql = "SELECT COUNT(*) FROM $table";

	  return $wpdb->get_var( $sql );
	  
	}	

	// FUNCTION TO PROCESS TABLE ACTIONS //
	
	public static function ai_mp_rp_process_table_action($module_args) 
	{
		$html="";
		$action=json_decode(ai_mp_rp_check_isset_value($module_args, 'action'))->value;
		$page_link=json_decode(ai_mp_rp_check_isset_value($module_args, 'page_link'))->value;
		$item_id=json_decode(ai_mp_rp_check_isset_value($module_args, 'item_id'))->value;
		$id=json_decode(ai_mp_rp_check_isset_value($module_args, 'id'))->value;
		$id_parameter=(ai_mp_rp_check_empty_value($id)==false) ? "&id=$id" : "";
		
		if($action=="edit")
		{
			$html='<a class="button" href="'.$page_link.$id_parameter.'"><span class="dashicons dashicons-edit"></span></a>';
		}
		
		return $html;
	  
	}	
	
	
	// FUNCTION TO DELETE RECORDS FROM TABLE //	
	
    public static function ai_mp_rp_delete_this_record($main_id,$module_args)
    {
        global $wpdb;
		$module = json_decode(ai_mp_rp_check_isset_value($module_args, 'module'))->value;
		$data_selection=json_decode(ai_mp_rp_check_isset_value($module_args, 'data_selection'))->value;
		$table_name = json_decode(ai_mp_rp_check_isset_value($data_selection, 'table'))->value;		
		$table = $wpdb->base_prefix.$table_name;

        $wpdb->delete($table, array(
            'id' => $main_id
        ), array(
            '%d'
        ));
    }
	 
	// CONSTRUCTOR REQUIRED FOR DECLARING DEFAULT CONFIG //
	
    function __construct()
    {
        global $status, $page;
        //Set parent defaults
        parent::__construct(array(
            'singular' => 'main_id', //singular name of the listed records
            'plural' => 'main_ids', //plural name of the listed records
            'ajax' => false //does this table support ajax?
        ));
    }

	// DEFAULT TABLE FUNCTION TO DECLARE COLUMN NAMES //
	
    function column_default($item, $column_name)
    {
		$html="";
		
		$module = $this->module;
		
		$module_args = $this->module_args;
		
		$columns_default_data = json_decode(ai_mp_rp_check_isset_value($module_args, 'columns_default'))->value;	
		
		
		if(isset($item[$column_name]))
		{			
				return $item[$columns_default_data->$column_name];
		}
		else
		{
			if(strtolower($column_name)=="actions")
			{
				if(isset($columns_default_data->actions))
				{
					foreach ($columns_default_data->actions as $single_action)
					{
							if(isset($single_action->item_id))
							{
								$single_action->id=$item[$single_action->item_id];
							}
							$html.=$this->ai_mp_rp_process_table_action($single_action);
					}
					
					return $html;
				}				
			}
		}	
        
    }
    

    // DEFAULT TABLE FUNCTION TO DECLARE COLUMN TITLES //
	
    function column_title($item)
    {
		
    }
    
	// DEFAULT TABLE FUNCTION TO DECLARE COLUMN (CB) AND MAIN IDS //
	
    function column_cb($item)
    {
        $module = $this->module;
	
			
            $main_id = $item['id'];
			return sprintf('<input type="checkbox" name="%1$s[]" value="%2$s" />', /*$1%s*/ $this->_args['singular'], //Let's simply repurpose the table's singular label ("main_id")
            /*$2%s*/ $main_id //The value of the checkbox should be the record's id
            );
			

    }
	
	// DEFAULT TABLE FUNCTION TO GET COLUMNS SLUGS //	
	
    function get_columns()
    {
		$module = $this->module;
		
		$module_args = $this->module_args;
			
		$columns_data=json_decode(ai_mp_rp_check_isset_value($module_args, 'columns'))->value;	
				
        $columns = (array) $columns_data;
		
        return $columns;
    }

	// FUNCTION TO DECLARE SORTABLE COLUMNS IN TABLE //	
	
    function get_sortable_columns()
    {
		$module = $this->module;
		
		$module_args = $this->module_args;
		
		$sortable_columns_data=json_decode(ai_mp_rp_check_isset_value($module_args, 'sortable_columns'))->value;
		
        $sortable_columns = (array) $sortable_columns_data;
       
        return $sortable_columns;
    }

	// DEFAULT TABLE FUNCTION TO DECLARE BULK ACTIONS //
	
	function get_bulk_actions() {

		$module = $this->module;
		
		$module_args = $this->module_args;
		
		$bulk_actions_data=json_decode(ai_mp_rp_check_isset_value($module_args, 'bulk_actions'))->value;		
	
			$actions = (array) $bulk_actions_data;
	
        return $actions;
    }
	
	// FUNCTION TO PROCESS BULK ACTION //	
	
    function process_bulk_action()
    {
        //Detect when a bulk action is being triggered..
        if ('delete' === $this->current_action()) {
            if (!empty($_REQUEST['main_id'])) {
                foreach ($_REQUEST['main_id'] as $main_id) {
                    $module_args = $this->module_args;
                    $this->ai_mp_rp_delete_this_record($main_id, $module_args);
                }
            }
        }
    }
  
	// FUNCTION TO PREPARE TABLE ITEMS AND PROCESS DATA //
  
	public function ai_mp_rp_prepare_table_items($args)
    {
        global $wpdb; //This is used only if making any database queries
		$total_pages=1;
		// PROCESS MODULE //
		
		$module = json_decode(ai_mp_rp_check_isset_value($args, 'module'))->value;
		$module_args = json_decode(ai_mp_rp_manage_admin_tables($args));
		//var_dump($module_args);
        $this->module  = $module;
        $this->module_args = $module_args;
		// PAGINATION FOR TABLES //
		
		$pagination = json_decode(ai_mp_rp_check_isset_value($module_args, 'pagination'))->value;
		
        $per_page              =  $pagination;
		
		// PROCESS TABLE ACTIONS //			
	   
        $columns               = $this->get_columns();
        $hidden                = array();
        $sortable              = $this->get_sortable_columns();
        $filter                = $this->get_sortable_columns();
        
		
		// DELCARE COLUMN HEADERS //
		
        $this->_column_headers = array(
            $columns,
            $hidden,
            $sortable
        );
        
		// PROCESS BULK ACTIONS //
		
        $this->process_bulk_action();
        
		// PROCESS TABLE DATA //
       
        $data = $this->ai_mp_rp_process_table_data($module_args);
        
		// GET CURRENT PAGE NUMBER //
	  
        $current_page = $this->get_pagenum();
        
		// CALCULATE TOTAL ITEMS FOR DATA //
		
        $total_items  = self::count_total_records($module_args);
       
		// TRIM TOTAL DATA TO SHOW THE PAGINATED DATA //
	   if(count($data) != 0)
	   {
         //$data  = array_slice($data, (($current_page - 1) * $per_page), $per_page);
		 $total_page= ceil($total_items / $per_page);
	   }

		// PUSH DATA TO ITEMS FOR TABLE SORTING //
	 
        $this->items  = $data;
        
		// REGISTER PAGINATION ARGUMENTS FOR PAGINATION //
		
        $this->set_pagination_args(array(
            'total_items' => $total_items, //WE have to calculate the total number of items
            'per_page' => $per_page, //WE have to determine how many items to show on a page
            'total_pages' => $total_pages  //WE have to calculate the total number of pages
        ));
    }
	
}