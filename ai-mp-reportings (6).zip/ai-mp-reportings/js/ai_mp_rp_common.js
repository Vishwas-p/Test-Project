// GLOBAL VAR //

var ai_mp_rp_owl;

// FUNCTION TO GET VALIDATION VALUE //

function ai_mp_rp_get_validation_value(container)
{
	var $this=jQuery(document).find(container);
	var value="";
    if ($this.is("input")) {
		
		if($this.is("input[type='radio']") || $this.is("input[type='checkbox']"))
		{
			var name=jQuery($this).attr('name');
			value=jQuery("input[name='"+name+"']").filter(":checked").val();		
			//alert(value);
		}
		else
		{
			value=jQuery($this).val();	
		}
        		
    } else if ($this.is("select")) {

		value=jQuery($this).find(":selected").val();
	
    } else if ($this.is("textarea")) {

		value=(ai_mp_rp_value_empty_check(jQuery($this).text())==true) ? jQuery($this).val() : jQuery($this).text();
	
    } else if ($this.next(".flatpickr-calendar").find(".flatpickr-day.selected").length) {
		
		value=($this.next(".flatpickr-calendar").find(".flatpickr-day.selected").length) ? $this.next(".flatpickr-calendar").find(".flatpickr-day.selected").attr('aria-label') : "";
		
    }	
	//alert(value);
	return value;
	
}

// FUNCTION TO CHECK EXTENDED VALIDATION //
function ai_mp_rp_get_extended_validation_value(container)
{
	var $this=jQuery(document).find(container);
	var value="";
	var result = false;
		if($this.is("input[type='email']"))
		{
			value=jQuery($this).val();		
			var email_regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			if(email_regex.test(value))
			{
				result=true;
			}
			
		}
		
		return result;
}

//--------FUNCTION TO CHECK IF VALUE IF NULL OR UNDEFINED OR EMPTY--------//

function ai_mp_rp_value_empty_check(value)
{
	var check_value=jQuery.trim(value);
	
	if(check_value=="" || check_value==0 || check_value===null || check_value=="undefined" || check_value=="NaN" || typeof check_value=="NaN"  ||  check_value==NaN || check_value===undefined || typeof check_value === "undefined" )
	{
		return true;
	}
	else
	{
		return false;
	}
}

// FUNCTION TO VALIDATE ELEMENTS //

function ai_mp_rp_validate_element(action,result,container)
{
	if(action=="single")
	{
		var value = ai_mp_rp_get_validation_value(container);
		var required = jQuery(container).attr('required');
		var message = jQuery(container).parents('.ai_mp_rp_required_element').find('.ai_mp_rp_required_error').html();
		if (typeof required !== typeof undefined && required !== false && ai_mp_rp_value_empty_check(value)==true) {
			
			if(result=="inline")
			{
				jQuery(container).parents('.ai_mp_rp_required_element').find('.ai_mp_rp_required_error').removeClass('ai_mp_rp_none');
			}
			else
			{
				ai_mp_rp_lightbox_init("alert","Please fill the required fields",message,"error");	
			}
			
			return false;
			
		}
		else
		{
			return true;
		}
	}
	else if(action=="all")
	{
		var modal_data = '';
		var modal_required= '';
		var status;
		var status_array = [];
		jQuery(document).find('.ai_mp_rp_required_error').addClass('ai_mp_rp_none');
		
				// SEND CONTAINER WITH ATTR AND VALUE  .container [required="yes"]
				
				// SEND CONTAINER WITH ATTR .container [required]	
				
				jQuery(document).find(container).each(function() 
				{
							
					var $this = jQuery(this);					
					var value = ai_mp_rp_get_validation_value($this);
					var required = jQuery($this).attr('required');
					var message = jQuery($this).parents('.ai_mp_rp_required_element').find('.ai_mp_rp_required_error').html();
					//alert(value);
					if (typeof required !== typeof undefined && required !== false && ai_mp_rp_value_empty_check(value)==true) {
						
							if(result=="inline")
							{
								jQuery($this).parents('.ai_mp_rp_required_element').find('.ai_mp_rp_required_error').removeClass('ai_mp_rp_none');
							}
							else
							{
								if(ai_mp_rp_check_word_exists(modal_data,message)==false)
								{
									modal_data += "<p>"+message+"</p>";
								}
								modal_required=true;	
							}	
							status_array.push("false");
							//status=false;
						}
						else
						{
							status_array.push("true");
							//status=true;
						}
			
				});
				
				console.log(status_array);
				
				if(ai_mp_rp_is_in_array('false',status_array))
				{
					status = false;
				}
				else
				{
					status = true;
				}
				
				if(modal_required==true)
				{
					ai_mp_rp_lightbox_init("alert","Please fill the required fields",modal_data,"error");	
				}
				
		return status;		
	}
	
	
}

// FUNCTION TO INIT FLATPICKER //

function ai_mp_rp_declare_flatpicker(type,container,method,parameters)
{
	var container=jQuery(document).find(container);
	if(jQuery(container).length)
	{	
		if(type=="date")
		{
				if(ai_mp_rp_value_empty_check(parameters)==true)
				{		
					if(ai_mp_rp_value_empty_check(method)==true)
					{
						if(ai_mp_rp_value_empty_check(parameters)==true)
						{
							jQuery(container).flatpickr({dateFormat: "Y-d-m",minDate: "today"});			
						}
					}
					else if(method=="inline")
					{
						if(ai_mp_rp_value_empty_check(parameters)==true)
						{
							jQuery(container).flatpickr({dateFormat: "Y-d-m",inline: true,minDate: "today"});		
						}			
									
					}
				}
				else
				{
					jQuery(container).flatpickr(parameters);			
				}
				

		}
		else if(type=="time")
		{
				if(ai_mp_rp_value_empty_check(parameters)==true)
				{
					jQuery(container).flatpickr({enableTime: true,noCalendar: true,dateFormat: "H:i"});
				}
				else
				{
					jQuery(container).flatpickr(parameters);
				}	
		}
	}
}

// FUNCTION TO CHECK IF VALUE EXIST IN ARRAY //

function ai_mp_rp_is_in_array(value, array) {
  return array.indexOf(value) > -1;
}

// FUNCTION TO INIT OWL CAROUSEL //


function ai_mp_rp_init_owl_carousel(container,attributes)
{
	ai_mp_rp_owl=jQuery(container).owlCarousel(attributes);
}

// FUNCTION TO INIT LIGHTBOX //

function ai_mp_rp_lightbox_init(type,title,content,status,footer,extra)
{
	
	// CODE TO CHECK THE TYPE OF MODAL BOX //
	
	var content_class;
	var title_class;
	
	if(type=='modal')
	{	
		content_class="ai_mp_rp_modal_lightbox_content";
		title_class="ai_mp_rp_modal_lightbox_title";
	}
	else if(type=="alert")
	{
		
		content_class="ai_mp_rp_alert_lightbox_content";
		title_class="ai_mp_rp_alert_lightbox_title";
		
		// CHECK STATUS ALERT //
		
		if(status=="success")
		{
			var title='<div class="ai_mp_rp_lightbox_title_status ai_mp_rp_lg_title_success"><i class="far fa-check-circle"></i> Success! '+title+'</div>';	
		}
		else if(status=="error")
		{
			var title='<div class="ai_mp_rp_lightbox_title_status ai_mp_rp_lg_title_error"><i class="fas fa-exclamation-circle"></i> Error! '+title+'</div>';		
		}
		else if(status=="warning")
		{
			var title='<div class="ai_mp_rp_lightbox_title_status ai_mp_rp_lg_title_warning"><i class="fas fa-exclamation-triangle"></i> Warning! '+title+'</div>';
		}
		
		var content='<div class="ai_mp_rp_lightbox_content_cnt">'+content+'</div>';	
		
		
	}
	
		// CODE TO APPEND TITLE //
		
		jQuery('.ai_mp_rp_lightbox_main_inner_title_content').html(title);
		jQuery('.ai_mp_rp_lightbox_main_inner_title_content').addClass(title_class);
		
		// CODE TO APPEND CONTENT //
		
		jQuery('.ai_mp_rp_lightbox_main_inner_content').html(content);	
		jQuery('.ai_mp_rp_lightbox_main_inner_content').addClass(content_class);
		
		// CODE TO APPEND FOOTER //
		
		jQuery('.ai_mp_rp_lightbox_main_inner_footer').html(footer);		
	
		// CODE TO FINALLY SHOW THE LIGHTBOX (SHOWTIME <!^^>) //
	
		jQuery(document).find('.ai_mp_rp_lightbox_overlay').show();
}

// FUNCTION TO CLOSE A LIGHTBOX AND RESET CONTENT //

jQuery(document).on("click",".ai_mp_rp_lightbox_close",function(e) {
	e.preventDefault();
	
	ai_mp_rp_resert_lightbox();
	
});

// FUNCTION TO MANAGE LIGHTBOX LOADING //

function ai_mp_rp_manage_lightbox_loading(action)
{
	
	if(action=='show')
	{
		jQuery('.ai_mp_rp_lightbox_loader').removeClass('ai_mp_rp_none');
	}
	else
	{
		jQuery('.ai_mp_rp_lightbox_loader').addClass('ai_mp_rp_none');
	}
	
}

// FUNCTION TO RESET LIGHTBOX //

function ai_mp_rp_resert_lightbox()
{
		jQuery(document).find('.ai_mp_rp_lightbox_overlay').hide();
	
		// CODE TO APPEND TITLE //
		
		jQuery('.ai_mp_rp_lightbox_main_inner_title_content').html('');
		
		// CODE TO APPEND CONTENT //
		
		jQuery('.ai_mp_rp_lightbox_main_inner_content').html('');
		
		// CODE TO APPEND FOOTER //
		
		jQuery('.ai_mp_rp_lightbox_main_inner_footer').html('');		
}

// FUNCTION TO APPEND PARAMETERS IN END OF A URL 

function ai_mp_rp_add_parameters_to_url(url,parameters)
{
	var url = (ai_mp_rp_value_empty_check(url)==true) ? window.location.href : url;    
	if (url.indexOf('?') > -1){
	   url += parameters;
	}else{
	   url += parameters;
	}
	
	return url;
}

// FUNTION TO CHECK IF A STRING CONSIST A WORD //

function ai_mp_rp_check_word_exists(string,word)
{
   if(string.indexOf(word) > -1) {
       return true;
    }
	else
	{
		return false;
	}	
}

// FUNCTION TO REMOVE SPACES //

function ai_mp_rp_remove_spaces_from_string(string)
{
	var result = string.replace(/\s+/g, '');
	
	return result;
}

// FUNCTION TO GENERATE RANDOM UNIQUE ID //

function ai_mp_rp_generate_random_unique_id(id)
{
	var number=id + '_' + (new Date().getUTCMilliseconds().toString() + new Date().getTime().toString()).toString();
	return number;
}