<?php

 //  CLASS USED FOR ACTIVATION / DEACTIVATION OF HOOKS 
 
class ai_mp_rp_db_settings
{
	
	// FUNCTION TO CREATE TABLES //
    function ai_mp_rp_create_table()
    {
 
    }
	
	// FUNCTION TO REMOVE TABLES //
	
	function ai_mp_rp_remove_table()
	{

	}	
}

// FUNCTION TO MANAGE POST EDIT COLUMNS //

function ai_mp_post_edit_column($cols) {
	$post_type = get_post_type();
	
    if ( $post_type == 'properties' || $post_type == 'iwp_property' ) {
		
       $cols['reports'] = __('View Reports', 'ai_mp');
	   
	}
    
	return $cols;
}

add_filter('manage_posts_columns', 'ai_mp_post_edit_column');

// FUNCTION TO MANAGE POST EDIT VALUES //

function  ai_mp_post_edit_value($column_name, $post_id) {
	
		$html="<div class='ai_mp_admin_reports_actions'>";
		$post_type = get_post_type();
		
        if ('reports' == $column_name) {
			
             $html.= '<a href="'.get_admin_url().'/admin.php?page=ai_mp_rp_sales_per_property_settings" title="Total Sales"><i class="fa fa-bar-chart" aria-hidden="true"></i></a>';
			 $html.= '<a href="'.get_admin_url().'/admin.php?page=ai_mp_rp_sales_catering_settings" title="Catering Sales"><i class="fa fa-coffee" aria-hidden="true"></i></a>';
			 $html.= '<a href="'.get_admin_url().'/admin.php?page=ai_mp_rp_sales_equipment_settings" title="Equipments Sales"><i class="fa fa-desktop" aria-hidden="true"></i></a>';
           
		   }
			
		$html.="</div>";	
		echo $html;
		
}
	 
 add_action('manage_posts_custom_column', 'ai_mp_post_edit_value', 10, 2); 
 
// FUNCTION TO MANAGE SIMPLE PAY SUCCESS PAGE FOR ADMIN PANEL // 
 
function simpay_custom_form_8133_payment_success_page( $url ) {
	
	GLOBAL $wpdb;
	GLOBAL $post;
	GLOBAL $current_screen;
				if ( $current_screen->action == 'add' ) {					
						if(!empty($post) || isset($_REQUEST['post']))
						{
						   $post_id=(isset($_REQUEST['post'])) ? $_REQUEST['post'] : $post->ID;
						   $url=home_url()."/wp-admin/post.php?post=".$post_id."&action=edit";
						}
						else
						{
							
						}
				}
				else
				{					
						if(!empty($post) || isset($_REQUEST['post']))
						{
						   $post_id=(isset($_REQUEST['post'])) ? $_REQUEST['post'] : $post->ID;
						   $url=home_url()."/wp-admin/post.php?post=".$post_id."&action=edit";
						}
						else
						{
						
						}
				}

	return $url;
	
}

add_filter( 'simpay_form_8133_payment_success_page', 'simpay_custom_form_8133_payment_success_page' ); 

// FUNCTION TO MANAGE FILTERS SUB QUERY //

function ai_mp_rp_manage_filters_sub_query($args="")
{
	GLOBAL $wpdb;
	$action=json_decode(ai_mp_rp_check_isset_value($args,'action'))->value;
	$date_range_from=ai_mp_rp_check_request("date_range_from");
	$date_range_to=ai_mp_rp_check_request("date_range_to");
	$duration=ai_mp_rp_check_request("duration");
	$property_id=ai_mp_rp_check_request("property_id");
	$space_id=ai_mp_rp_check_request("space_id");
	$sub_query="";
	$sub_query_table="";
	$post_meta_table=$wpdb->base_prefix."postmeta";
	$results=array();
	
	
	if(ai_mp_rp_check_empty_value($property_id)==false) // CASE FOR PROPERTY ONLY //
	{
		$sub_query_table.=",".$post_meta_table." pr";		
		$sub_query.=" AND pr.meta_key='properties_id' AND pr.meta_value='".$property_id."' AND p.ID=pr.post_id";
	}
	
	
	if(ai_mp_rp_check_empty_value($space_id)==false) // CASE FOR SPACE ONLY //
	{

		$sub_query_table.=",".$post_meta_table." sp";			

		$sub_query.=" AND sp.meta_key='space_id' AND sp.meta_value='".$space_id."' AND p.ID=sp.post_id";		
	}
	
	if(ai_mp_rp_check_empty_value($duration)==false) // CASE FOR DURATION ONLY //
	{

		if($duration=="7days")
		{
			$sub_query.=" AND DATE(p.post_date)  >= (DATE(NOW()) - INTERVAL 7 DAY)";	
		}
		else if($duration=="1month")
		{
			$sub_query.=" AND YEAR(p.post_date) = YEAR(CURDATE()) AND MONTH(p.post_date) = MONTH(CURDATE())";	
		}
		else if($duration=="1year")
		{
			$sub_query.=" AND YEAR(p.post_date) = YEAR(CURDATE())";	
		}
		
	
	}	
	
	if(ai_mp_rp_check_empty_value($date_range_from)==false || ai_mp_rp_check_empty_value($date_range_to)==false) // CASE FOR RANGE ONLY //
	{
		if(ai_mp_rp_check_empty_value($date_range_from)==false && ai_mp_rp_check_empty_value($date_range_to)==false)
		{
			$sub_query.=" AND YEAR(p.post_date) = YEAR(CURDATE()) AND DATE(p.post_date) BETWEEN '$date_range_from' AND '$date_range_to'";			
		}
		else 
		{
			$date_to_check=(ai_mp_rp_check_empty_value($date_range_from)==false) ? $date_range_from : $date_range_from;
			
			$sub_query.=" AND YEAR(p.post_date) = YEAR(CURDATE()) AND DATE(p.post_date)='$date_to_check'";				
		}
		
	}
	
	$results['table']=$sub_query_table;
	$results['sub_query']=$sub_query;
	
	return $results;
	
}

// FUNCTION TO MANAGE ALL SPACES

function ai_mp_rp_manage_post_types($args="")
{
	GLOBAL $wpdb;
	GLOBAL $wp_roles;
	$user_role=ai_mp_rp_get_user_role();
	$action=json_decode(ai_mp_rp_check_isset_value($args,'action'))->value;
	$post_type=json_decode(ai_mp_rp_check_isset_value($args,'post_type'))->value;	
	$classes=json_decode(ai_mp_rp_check_isset_value($args,'classes'))->value;	
	$default=json_decode(ai_mp_rp_check_isset_value($args,'default'))->value;	
	$all_posts_args=(ai_mp_rp_check_empty_value(ai_mp_rp_check_isset_value($args,'post_args','yes'))==false) ? ai_mp_rp_check_isset_value($args,'post_args','yes') : array();
	
	$html="";
		if($action=="dropdown")
		{
						$html.="<select class='".$classes."'>";
							
								$all_posts_args['post_type'] = $post_type;	
								$all_posts_args['posts_per_page'] = -1;
							//	var_dump($all_posts_args);
								if(strtolower($user_role)=="administrator")
								{
									$all_posts=ai_mp_rp_get_posts_by_args($all_posts_args);
								}
								else
								{
									$all_posts_args['author'] = $user_id;
									$all_posts=ai_mp_rp_get_posts_by_args($all_posts_args);
								}	
								$html.='<option value="">'.$default.'</option>';
									foreach($all_posts as $single_post)
									{						
										$post_id=$single_post->ID;
										$selected=($property_id==$post_id) ? "selected" : "";
										$post_title=$single_post->post_title;
										$html.='<option '.$selected.' value="'.$post_id.'">'.$post_title.'</option>';
									}	
							
						
						$html.="</select>";	

		}


return $html;		
	
}
	