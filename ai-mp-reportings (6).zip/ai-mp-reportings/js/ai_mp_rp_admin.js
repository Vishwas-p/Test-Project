jQuery(document).ready()
{
	if(jQuery(document).find(".ai_mp_rp_date_ranges"))
	{
		
		var from_date=jQuery(document).find(".ai_mp_rp_date_ranges_from").val();
		var from_date=(ai_mp_rp_value_empty_check(from_date)==false) ? from_date : "";	
		var to_date=jQuery(document).find(".ai_mp_rp_date_ranges_to").val();
		var to_date=(ai_mp_rp_value_empty_check(from_date)==false) ? from_date : "";	
	
						ai_mp_rp_declare_flatpicker("date",jQuery(document).find(".ai_mp_rp_date_ranges"),"",
						{	dateFormat: "Y-m-d",
							inline: false,
							minDate: from_date,
							mode:'range',
							defaultDate:[from_date,to_date],
							onChange: function(selectedDates, dateStr, instance) {
								jQuery(".ai_mp_rp_date_ranges_from").val('');
								jQuery(".ai_mp_rp_date_ranges_to").val('');								
							    if(dateStr.indexOf('to') !== -1)
								{
									var date_range = dateStr.split("to");
									var start_date=ai_mp_rp_remove_spaces_from_string(date_range[0]);
									var end_date=ai_mp_rp_remove_spaces_from_string(date_range[1]);
									jQuery(".ai_mp_rp_date_ranges_from").val(start_date);
									jQuery(".ai_mp_rp_date_ranges_to").val(end_date);									
								}
								else
								{
									jQuery(".ai_mp_rp_date_ranges_from").val(dateStr);
								}
								
								
								// CALL MAIN FUNCTION // 
								
								ai_mp_rp_manage_reporting_filters("reset_durations");
								
							}								
						});	
						
						
	}
}

// DETECT FILTER CHANGE FOR PROPERTY //

jQuery(document).on("change",".ai_mp_rp_main_actions_cnt .ai_mp_rp_filters_property_selector",function(e) {
	e.preventDefault();
	ai_mp_rp_manage_dropdowns("space");
	
});


// DETECT FILTER CHANGE FOR SPACE //

jQuery(document).on("change",".ai_mp_rp_main_actions_cnt .ai_mp_rp_filters_space_selector",function(e) {
	e.preventDefault();	
	//ai_mp_rp_manage_reporting_filters();	
	
});

// DETECT FILTER CHANGE FOR DURATION //

jQuery(document).on("change",".ai_mp_rp_main_actions_cnt .ai_mp_rp_filters_duration_selector",function(e) {
	e.preventDefault();	
	ai_mp_rp_manage_reporting_filters("reset_picker");	
	
});

// EVENT TO INIT THE SEARCH FILTER //

jQuery(document).on("click",".ai_mp_rp_filter_results",function(e) {
	e.preventDefault();	
	ai_mp_rp_manage_reporting_filters("filter");	
	
});


// FUNCTION TO MANAGE FILTERS FOR REPORTINGS //

function ai_mp_rp_manage_reporting_filters(type)
{
	
	if(type=="filter")
	{
	
			var main_action_cnt=jQuery(document).find(".ai_mp_rp_main_actions_cnt");

			
			var date_range_from=jQuery(main_action_cnt).find('.ai_mp_rp_date_ranges_from').val();	
			var date_range_to=jQuery(main_action_cnt).find('.ai_mp_rp_date_ranges_to').val();
			var duration=jQuery(main_action_cnt).find('.ai_mp_rp_filters_duration_selector option:selected').val();
			var property_id=jQuery(main_action_cnt).find('.ai_mp_rp_filters_property_selector option:selected').val();
			var space_id=jQuery(main_action_cnt).find('.ai_mp_rp_filters_space_selector option:selected').val();
			var module=jQuery(main_action_cnt).attr('module');

			
			var main_action="action=ai_mp_rp_manage_filters_cont";	
			
			var formData=main_action+"&date_range_from="+date_range_from+"&date_range_to="+date_range_to+"&duration="+duration+"&property_id="+property_id+"&space_id="+space_id+"&ajax=yes&main_action=filter&module="+module;
			
			jQuery.ajax({
				type: "post",
				dataType: "json",
				url: ai_mp_rp_custom_params.ajax_url,
				data: formData,
				success: function(data){
					if(ai_mp_rp_value_empty_check(data)==false)
					{
						var all_data=data.data.shift();
						var all_dataset=[];
						var all_labels=[];
						
								for (const [key, value] of Object.entries(all_data)) {
									all_dataset.push(parseInt(value));
									all_labels.push(key);
								}
					
						all_dataset=all_dataset;
						all_labels=all_labels;
						myChart.data.datasets[0].data=all_dataset;
						myChart.data.labels=all_labels;
						myChart.update();
					}
				}
			});	

	}
	else if(type=="reset_picker")
	{
		// jQuery(document).find(".ai_mp_rp_date_ranges").flatpickr().clear();
	}	
	else if(type=="reset_durations")
	{
		jQuery(document).find('.ai_mp_rp_filters_duration_selector').val('1year').change();
		
	}
}

// FUNCTION TO MANAGE DROPDOWNS //

function ai_mp_rp_manage_dropdowns(action)
{
	
	if(action=="space")
	{
	
		var main_action="action=ai_mp_rp_manage_filters_cont";	
		var main_action_cnt=jQuery(document).find(".ai_mp_rp_main_actions_cnt");
		var property_id=jQuery(main_action_cnt).find('.ai_mp_rp_filters_property_selector option:selected').val();	
		var classes = "ai_mp_rp_filters_space_selector";
		var post_type = "iwp_property";
		var default_label = "Please select a space";
		var formData=main_action+"&module=dropdown"+"&property_id="+property_id+"&ajax=yes"+"&classes="+classes+"&post_type="+post_type+"&default_label="+default_label;
		
		jQuery.ajax({
			type: "post",
			url: ai_mp_rp_custom_params.ajax_url,
			data: formData,
			success: function(data){
				if(ai_mp_rp_value_empty_check(data)==false)
				{				
						jQuery(document).find(".ai_mp_rp_space_drop_cnt").html(data);
			
				}
			}
		});	
		
	}	
}

// EVENT TO INIT DOWNLOAD OF REPORTS IN PDF FORMAT //

jQuery(document).on("click",".ai_mp_rp_download_report",function() 
{
	// get size of report page
	var reportPageHeight = jQuery('.ai_mp_rp_reports_cnt').innerHeight();
	var reportPageWidth = jQuery('.ai_mp_rp_reports_cnt').innerWidth();

	// create a new canvas object that we will populate with all other canvas objects
	var pdfCanvas = $('<canvas />').attr({
		id: "canvaspdf",
		width: reportPageWidth,
		height: reportPageHeight
	});

	// keep track canvas position
	var pdfctx = $(pdfCanvas)[0].getContext('2d');
	var pdfctxX = 0;
	var pdfctxY = 0;
	var buffer = 100;

	// for each chart.js chart
	jQuery("canvas").each(function(index) {
		// get the chart height/width
		var canvasHeight = $(this).innerHeight();
		var canvasWidth = $(this).innerWidth();
		// draw the chart into the new canvas
		pdfctx.drawImage($(this)[0], pdfctxX, pdfctxY, canvasWidth, canvasHeight);
		pdfctxX += canvasWidth + buffer;

		// our report page is in a grid pattern so replicate that in the new canvas
		if (index % 2 === 1) {
		  pdfctxX = 0;
		  pdfctxY += canvasHeight + buffer;
		}
	});

	// create new pdf and add our new canvas as an image
	var pdf = new jsPDF('l', 'pt', [reportPageWidth, reportPageHeight]);
	pdf.addImage($(pdfCanvas)[0], 'PNG', 0, 0);
	// download the pdf
	var unique_rand_number = ai_mp_rp_generate_random_unique_id('mp');
	pdf.save(unique_rand_number+'.pdf');
});