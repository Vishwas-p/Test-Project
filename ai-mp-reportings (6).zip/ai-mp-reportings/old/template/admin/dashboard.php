<?php 

function ai_mp_rp_manage_sales_extra_temp($args)
{

extract($args);
$html="";
?>

		<div class="wrap" >
			<?php global $wp_roles; ?>   
		   <div class="content demo_responsive">
			  <div class="ai_aio_tabs_list">
			  <h1>Sales (<?php echo ucfirst($module); ?>)</h1>
			  
			  <div class="ai_mp_rp_main_actions_cnt clearfix" module="<?php echo $module; ?>">	
					<div class="ai_mp_rp_main_range_cnt ai_mp_rp_right ai_mp_main_actions_items">
						<select class="ai_mp_rp_filters_space_selector">
							<option value="">Please select a property first</option>
						</select>					
					</div>				  
					<div class="ai_mp_rp_main_range_cnt ai_mp_rp_right ai_mp_main_actions_items">
						<select class="ai_mp_rp_filters_property_selector">
							<?php
								$all_posts_args['post_type'] = 'properties';
								
								if(strtolower($user_role)=="administrator")
								{
									$all_posts=ai_mp_get_posts_by_args($all_posts_args);
								}
								else
								{
									$all_posts_args['author'] = $user_id;
									$all_posts=ai_mp_get_posts_by_args($all_posts_args);
								}	
								$html.='<option value="">Please select a property</option>';
									foreach($all_posts as $single_post)
									{						
										$post_id=$single_post->ID;
										$selected=($property_id==$post_id) ? "selected" : "";
										$post_title=$single_post->post_title;
										$html.='<option '.$selected.' value="'.$post_id.'">'.$post_title.'</option>';
									}	
								echo $html;
							?>
						</select>					
					</div>			  
					<div class="ai_mp_rp_main_range_cnt ai_mp_rp_right ai_mp_main_actions_items">
						<select class="ai_mp_rp_filters_duration_selector">
							<option value="7days">Past 7 days</option>
							<option value="1month">Present Month</option>
							<option value="1year" selected>Present Year</option>
						</select>					
					</div>				  
					<div class="ai_mp_rp_main_custom_range_cnt ai_mp_rp_right ai_mp_main_actions_items">

							<div class="ai_mp_rp_date_ranges clearfix flatpickr-input" ><i class="far fa-calendar-alt"></i></div>
							<input type="hidden" class="ai_mp_rp_date_ranges_from" name="ai_mp_rp_date_ranges_from" />
							<input type="hidden" class="ai_mp_rp_date_ranges_to" name="ai_mp_rp_date_ranges_to" />
				
					</div>		  
			  </div>
			<?php  
			$data= json_decode(ai_mp_rp_check_isset_value($args, 'data','yes'));	
			
			if($data->status=="success")
			{
				
				$data=reset($data->data);
				$labels=array();
				$datasets=array();
				if(!empty($data))
				{
					
					foreach($data as $key => $value)
					{
						$datasets[]= $value;
						$labels[]="'".$key."'";
					}
					
					$datasets=array("label"=>"Sales (".ucfirst($module).")","data"=>$datasets);
					$labels=implode($labels,',');
				}
	
			}

			?>
					<div class="pt-2">
						  <canvas id="myChart" width="850" height="350"></canvas>
						   <script>
								//chartjs plugin //
								var ctx = document.getElementById("myChart").getContext('2d');
								 myChart = new Chart(ctx, {
									type: 'bar',
									data: {
										labels: [<?php echo $labels; ?>],
										datasets: [<?php echo json_encode($datasets); ?>]
									},
									options: {
										scales: {
											yAxes: [{
												ticks: {
													beginAtZero:true
												}
											}]
										}
									}
								});
						   </script>
					</div>	
				</div>
			</div>
		</div>
	
<?php
}

function ai_mp_rp_manage_sales_per_property_temp($args)
{
	extract($args);
	$html="";
?>	
		<div class="wrap" >
			<?php global $wp_roles; ?>   
		   <div class="content demo_responsive">
			  <div class="ai_aio_tabs_list">
			  <h1>Sales (Total Sales Overview)</h1>
			  
			  <div class="ai_mp_rp_main_actions_cnt clearfix" module="<?php echo $module; ?>">	
					<div class="ai_mp_rp_main_range_cnt ai_mp_rp_right ai_mp_main_actions_items ai_mp_rp_space_drop_cnt">
						<select class="ai_mp_rp_filters_space_selector">
							<option value="">Please select a property first</option>
						</select>					
					</div>				  
					<div class="ai_mp_rp_main_range_cnt ai_mp_rp_right ai_mp_main_actions_items">
							<?php							
								echo ai_mp_rp_manage_post_types(array("action"=>"dropdown","post_type"=>"properties","classes"=>"ai_mp_rp_filters_property_selector","default"=>"Please select a property"));
							?>
					</div>						
					<div class="ai_mp_rp_main_range_cnt ai_mp_rp_right ai_mp_main_actions_items">
						<select class="ai_mp_rp_filters_duration_selector">
							<option value="7days">Past 7 days</option>
							<option value="1month">Present Month</option>
							<option value="1year" selected>Present Year</option>
						</select>					
					</div>					
					<div class="ai_mp_rp_main_custom_range_cnt ai_mp_rp_right ai_mp_main_actions_items">

							<div class="ai_mp_rp_date_ranges clearfix flatpickr-input" ><i class="far fa-calendar-alt"></i></div>
							<input type="hidden" class="ai_mp_rp_date_ranges_from" name="ai_mp_rp_date_ranges_from" />
							<input type="hidden" class="ai_mp_rp_date_ranges_to" name="ai_mp_rp_date_ranges_to" />
				
					</div>		  
			  </div>
			<?php  
			$data= json_decode(ai_mp_rp_check_isset_value($args, 'data','yes'));	
			
			if($data->status=="success")
			{
				
				$data=reset($data->data);
				$labels=array();
				$datasets=array();
				if(!empty($data))
				{
					
					foreach($data as $key => $value)
					{
						$datasets[]= $value;
						$labels[]="'".$key."'";
					}
					
					$datasets=array("label"=>"Sales (Total Sales Overview)","data"=>$datasets);
					$labels=implode($labels,',');
				}
	
			}

			?>
					<div class="pt-2">
						  <canvas id="myChart" width="850" height="350"></canvas>
						   <script>
						   var myChart;
								//chartjs plugin //
								var ctx = document.getElementById("myChart").getContext('2d');
								myChart = new Chart(ctx, {
									type: 'bar',
									data: {
										labels: [<?php echo $labels; ?>],
										datasets: [<?php echo json_encode($datasets); ?>]
									},
									options: {
										scales: {
											yAxes: [{
												ticks: {
													beginAtZero:true
												}
											}]
										}
									}
								});
						   </script>
					</div>	
				</div>
			</div>
		</div>
<?php		
}
?>