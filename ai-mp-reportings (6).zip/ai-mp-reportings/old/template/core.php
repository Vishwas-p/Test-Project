<?php
include_once("admin/core.php");