<?php

// LOAD WORDPRESS DEFAULT PLUGGABLE FUNCTIONS //

require( ABSPATH . WPINC . '/pluggable.php' );
require( ABSPATH . WPINC . '/pluggable-deprecated.php' );

// INCLLUDE SCRIPTS AND CLASSES //

include_once ("includes/includes.php");

// LOAD IMPORTANT CLASSES AND FUNCTIONS //

include_once ("common/common.php");
include_once ("common/tables.php");
include_once ("common/notices.php");

// LOAD HELPERS FOR MVC MODULES //

include_once ("helpers/admin/dashboard.php");

// LOAD FRAMEWORK ACCORDING TO MVC //

include_once ("controller/core.php");
include_once ("model/core.php");
include_once ("template/core.php");