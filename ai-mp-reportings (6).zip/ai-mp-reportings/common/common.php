<?php
// FUNCTION TO CHECK REQUESTS //

function ai_mp_rp_check_request($value) 

{
	if (isset($_REQUEST[$value]))
	{
		return $_REQUEST[$value];
	}
	else
	{
		return "";
	}
}

// FUNCTION TO CHECK ISSET VALUE //

// FUNCTION TO CHECK IF ISSET VALUE EXIST OR NOT //

function ai_mp_rp_check_isset_value($data, $field,$preserve="")
{
	$json_data = array();
	$val="";
	
	if(is_object($data)){

		if (isset($data->$field))
		{
			$val = $data->$field;
		}
		
	}
	else if(is_array($data)){
		if (isset($data[$field]))
		{
			$val = $data[$field];
		}
	}	
	
	if(!empty($preserve) && $preserve=="yes")
	{
		return $val;
	}
	else
	{
		$json_data['value'] = $val;
		return json_encode($json_data);
	}


}

// FUNCTION TO CHECK JSON DATA //

function ai_mp_rp_check_json_data($data, $field)
{
	if (isset($data->$field))
	{
		return $data->$field;
	}
	else
	{
		return "";
	}
}

// FUNCTION TO CHECK EMPTY VALUE //

function ai_mp_rp_check_empty_value($data)
{
	if(is_array($data) && count($data) > 0 || !empty($data))
	{
		return false;
	}
	else
	{
		return true;
	}
}

/* RANDOM  VALUE */
function ai_mp_rp_random_value()
{
	$random = time() . uniqid(mt_rand() , true);
	return $random;
}


// FUNCTION TO GET HOURS OR MINUTES BETWEEN TWO DATE TIME //

function ai_mp_rp_count_hours_between_two_datetime($args)
{
	$results=array();
	$type = json_decode(ai_mp_rp_check_isset_value($args, 'type'))->value;
	$timezone_conversion = json_decode(ai_mp_rp_check_isset_value($args, 'timezone_conversion'))->value;
	$datetime_from = json_decode(ai_mp_rp_check_isset_value($args, 'datetime_from'))->value;
	$datetime_to = json_decode(ai_mp_rp_check_isset_value($args, 'datetime_to'))->value;
	$timezone_from = json_decode(ai_mp_rp_check_isset_value($args, 'timezone_from'))->value;
	$timezone_to = json_decode(ai_mp_rp_check_isset_value($args, 'timezone_to'))->value;

		if(ai_mp_rp_check_empty_value($datetime_from)==false && ai_mp_rp_check_empty_value($datetime_to)==false)
		{
			
				if($timezone_conversion=="yes")
				{
					$datetime_from=ai_of_convert_timezone("server_to_user",$datetime_from,"Y-m-d H:i",$timezone_to,$timezone_from);
					$datetime_to=ai_of_convert_timezone("server_to_user",$datetime_to,"Y-m-d H:i",$timezone_to,$timezone_from);
				}
				
				$d1= new DateTime($datetime_from); 
							
				$d2= new DateTime($datetime_to);
							
				$interval= $d1->diff($d2);
				
				if($type=="hours")
				{							
					$results["hours"]=($interval->days * 24) + $interval->h;	
				}
				else
				{
					$results["hours"]=($interval->days * 24) + $interval->h;
					$results["minutes"]=($interval->days * 24 * 60) + ($interval->h * 60) + $interval->i;				
				}
	
		}
	
	return json_encode($results);
}

// FUNCTION TO GET THEME FILES / BLOCKS //

function ai_mp_rp_get_theme_part($type,$module,$themepart,$attr="",$extra="")
{
	$link="";
	// DECLARING OBJECT START TO ESCAPE ERRORS / FLUSH ERRORS //
	
        ob_start();
		
	// CHECK FOR TYPE OF INCLUSION //	

		if($type=="user")
		{
			$link.=OFWSDIRPATH.'/'.$module.'/'.$themepart.'.php';						
		}
		else if($type=="admin")	
		{
			$link.=OFWSDIRPATH.'/'.$module.'/admin/'.$themepart.'.php';	
		}	
		
		
		
	// CHECK IF FILE EXIST IN LOCATION OR DONT LOAD IT //
		
			if(file_exists($link))
			{
				include($link);
			}
		
		
	
        $html = ob_get_contents();
		
        ob_end_clean();
		
	// ENDING OBJECT START TO ESCAPE ERRORS / FLUSH ERRORS //
		
        return $html;	
}

// FUNCTION TO SEND EMAILS // 
 
function ai_mp_rp_send_emails($args)
{
	$to = json_decode(ai_mp_rp_check_isset_value($args, 'to'))->value;
	$subject = json_decode(ai_mp_rp_check_isset_value($args, 'subject'))->value;
	$message = json_decode(ai_mp_rp_check_isset_value($args, 'message'))->value;
	$headers = json_decode(ai_mp_rp_check_isset_value($args, 'headers'))->value;
	
	if ( function_exists( 'mail' ) )
		{
			
			if (wp_mail($to, $subject, $message, $headers))
			{				
				return true;
			}
			else
			{
				return false;			
			}
		}
} 

// FUNCTION TO GET POSTS BY ARGUMENTS //

function ai_mp_rp_get_posts_by_args($args="")
{
	GLOBAL $wpdb;
	
	$all_args=array('order'=>'DESC','post_type'=>'post','orderby'=>'date','category'=>0,'numberposts'=>10);
	
	if(ai_mp_rp_check_empty_value($args)==false)
	{
		foreach($args as $key => $value)
		{
			$all_args[$key]=$value;
		}
	}
	
	
	return get_posts( $all_args ); 
 	
}

// FUNCTION TO GET USERS BY USER ROLE //

function ai_mp_rp_get_users_by_agrs($args)
{
	$results=array();
	$type = json_decode(ai_mp_rp_check_isset_value($args, 'type'))->value;
	$classes = json_decode(ai_mp_rp_check_isset_value($args, 'classes'))->value;
	$selected = json_decode(ai_mp_rp_check_isset_value($args, 'selected'))->value;
	$extra_args = json_decode(ai_mp_rp_check_isset_value($args, 'extra_args'))->value;
	$html="";

		$args = array(
			'role'    => 'subscriber',
			'orderby' => 'user_nicename',
			'order'   => 'ASC'
		);
		
	if(ai_mp_rp_check_empty_value($extra_args)==false)
	{
		foreach($extra_args as $key => $value)
		{
			$args[$key]=$value;
		}
	}
		
	$users = get_users( $args );
	
	if($type=="select")
	{		
		if(ai_mp_rp_check_empty_value($users)==false)
		{
			$html.="<select class='$classes' name='$classes'>";
			
			foreach ( $users as $user ) {
				
				$selected_option=(ai_mp_rp_check_empty_value($selected)==false && $selected==$user->ID) ? "selected" : "";
				$html.= '<option '.$selected_option.' value="' . esc_html( $user->ID ) . '">' . esc_html( $user->display_name ) . '[' . esc_html( $user->user_email ) . ']</option>';
				
			}		
			
			$html.= "</select>";
			
			$results['status']="success";
			$results['data']=$html;				
		}
		else
		{
			$results['status']="error";
		}
		
	}
	else if($type=="li")
	{
		if(ai_mp_rp_check_empty_value($users)==false)
		{		
			$html.="<ul class='$classes'>";
			
				foreach ( $users as $user ) {
					
					$selected_option=(ai_mp_rp_check_empty_value($selected)==false && $selected==$user->ID) ? "active" : "";
					$html.='<li '.$selected_option.' data="' . esc_html( $user->ID ) . '">' . esc_html( $user->display_name ) . '[' . esc_html( $user->user_email ) . ']</li>';
				
				}
			
			$html.= '</ul>';
			$results['status']="success";
			$results['data']=$html;				
		}
		else
		{
			$results['status']="error";
		}	
		
	}
	else if($type=="raw")
	{
		if(ai_mp_rp_check_empty_value($users)==false)
		{		
			$html.= $users;
			$results['status']="success";
			$results['data']=$html;				
		}
		else
		{
			$results['status']="error";
		}
		
	}
	
	return json_encode($results);
	
}


// FUNCTION TO MANAGE ALL KIND OF MYSQL SELECT QUERIES //

function ai_mp_rp_get_raw_results($args,$extra="")
{
	GLOBAL $wpdb;
	$results=array();
	$method=json_decode(ai_mp_rp_check_isset_value($args, 'method'))->value;
	$type=json_decode(ai_mp_rp_check_isset_value($args, 'type'))->value;	
	$tables=json_decode(ai_mp_rp_check_isset_value($args, 'tables'))->value;
	$fields=json_decode(ai_mp_rp_check_isset_value($args, 'fields'))->value;
	$values=json_decode(ai_mp_rp_check_isset_value($args, 'values'))->value;
	$conditions=json_decode(ai_mp_rp_check_isset_value($args, 'conditions'))->value;

	$order=json_decode(ai_mp_rp_check_isset_value($args, 'order'))->value;
	
	$conditions_query = $order_query = $values_query = $fields_query = $tables_query = "";
	
	// GENERATE TABLES QUERIES // ~ START
	
	$all_tables=array();
	
	foreach($tables as $table)
	{
		$all_tables[]=$wpdb->base_prefix.$table;
	}	
	
	$tables_query=(ai_mp_rp_check_empty_value($all_tables)==false) ? implode(",",$all_tables) : "";	
	
	// GENERATE TABLES QUERIES // ~ END
	
	if($method=="select")
	{
		
		// GENERATE CONDITIONS FOR QUERIES //
	
		$conditions_query=(ai_mp_rp_check_empty_value($conditions)==false) ? implode(" AND ",$conditions) : "";
		
		// GENERATE ORDER BY FOR QUERIES //
		
		$order_query=(ai_mp_rp_check_empty_value($order)==false) ? implode(" ",$order) : "";	
			
		// GENERATE FIELDS QUERIES //
		
		$fields_query = (ai_mp_rp_check_empty_value($fields)==false) ?  implode(",",$fields) : "*";
		
		// GENERATE MAIN QUERY //
		
		$sql_query="SELECT $fields_query FROM $tables_query WHERE $conditions_query $order_query";

		if($type=="row" || $type=="single")
		{
			$query=$wpdb->get_row($sql_query);
		}
		else if($type=="value")
		{
			$query=$wpdb->get_var($sql_query); 
		}
		else if($type=="all")
		{
			$query=$wpdb->get_results($sql_query);
		}
		
		if ( $query ) {
			
			$results['status']="success";
			$results['data']=$query;
			
		}
		else
		{
			$results['status']="error";
			$results['data']=$query;			
		}
		
	}
	
	
	return json_encode($results);
}

// FUNCTION TO GET DATA FROM META TABLES //

function ai_mp_rp_get_all_meta_details($args)
{
		$results = $meta_data = $all_data = array();
		$results['status']="error";
		$results['data'] = "";
		$type = json_decode(ai_mp_rp_check_isset_value($args, 'type'))->value;
		$meta_table = json_decode(ai_mp_rp_check_isset_value($args, 'meta_table'))->value;
		$meta_conditions = json_decode(ai_mp_rp_check_isset_value($args, 'meta_conditions'))->value;
		$meta_fields = json_decode(ai_mp_rp_check_isset_value($args, 'meta_fields'))->value;
		$user_meta_args=array(
					'method' => 'select',
					'type' => 'all',
					'tables' => $meta_table,
					'fields' => $meta_fields,
					'conditions' => $meta_conditions
				);		
		$user_meta = json_decode(ai_mp_rp_get_raw_results($user_meta_args), true); // get data from user_meta table ;	
		
	if($type!="meta_only")
	{
		$table = json_decode(ai_mp_rp_check_isset_value($args, 'table'))->value;
		$conditions = json_decode(ai_mp_rp_check_isset_value($args, 'conditions'))->value;
		$fields = json_decode(ai_mp_rp_check_isset_value($args, 'fields'))->value;
		$user_args=array(
					'method' => 'select',
					'type' => 'single',
					'tables' => $table,
					'fields' => $fields,
					'conditions' => conditons
				);
		$user = json_decode(ai_mp_rp_get_raw_results($user_args) , true); // get data from user table (located in same file);		
		
		if ($user['status'] == "success")
		{
			$data = $user['data'];
			foreach($data as $key => $main_data)
			{
				$all_data[$key] = $main_data;
			}
			
			$results['status']="success";
			$results['data'] = $all_data;				
		}				
	}

	if ($user_meta['status'] == "success")
	{
		$meta_data = $user_meta['data'];			
		if ((is_array($meta_data) && count($meta_data) > 0 && $type =="meta_only") || (is_array($meta_data) && count($meta_data) > 0))
		{
			foreach($meta_data as $main_data)
			{
				if (isset($main_data['type']))
				{
					$main_type = $main_data['type'];
				}
				if (isset($main_data['value']))
				{
					$main_value = $main_data['value'];
				}
				$all_data[$main_type] = $main_value;
			}
		}
			$results['status']="success";
			$results['data'] = $all_data;		
	}
	
	return json_encode($results);
}

// GENERATE BUDDYPRESS PRIVATE MESSAGE LINK FOR A RECEIVER //

function ai_mp_rp_bp_get_compose_link_for_a_receiver($args)
{
		GLOBAL $wpdb,$bp;
		$user_id=json_decode(ai_mp_rp_check_isset_value($args, 'user_id'))->value;
		$user_id=(ai_mp_rp_check_empty_value($user_id)==false) ? $user_id : get_current_user_id();
		$receiver_id=json_decode(ai_mp_rp_check_isset_value($args, 'receiver_id'))->value;
		$compose_url=bp_core_get_user_domain( $user_id ). bp_get_messages_slug() . '/compose/?';
		
		if(ai_mp_rp_check_empty_value($compose_url)==false)
		{
			$compose_url.=('r=' . bp_core_get_username( $receiver_id ));
		}

		return $compose_url;
}

// FUNCTION TO CHECK IF A VALUE EXIST IN MULTIARRAY //

function ai_mp_rp_check_if_value_in_mu_array($value, $array, $strict = false) {
	
    foreach ($array as $item) {
        if (($strict ? $item === $value : $item == $value) || (is_array($item) && ai_mp_rp_check_if_value_in_mu_array($value, $item, $strict)!==FALSE)) {
            return true;
        }
    }
}

// FUNCTION TO CHECK IF SLOT EXIST BETWEEN TWO SLOTS //

function ai_mp_rp_check_if_slot_exist_between_two_slots($t1, $t2, $tn) {
    $t1 = +str_replace(":", "", $t1);
    $t2 = +str_replace(":", "", $t2);
    $tn = +str_replace(":", "", $tn);
    if ($t2 >= $t1) {
        if($t1 <= $tn && $tn < $t2)
		{
			return true;
		}
    } else {
        if(!($t2 <= $tn && $tn < $t1))
		{
			return true;
		}
    }
}

// FUNCTION TO GET START AND END DATE OF A WEEK //

function ai_mp_rp_get_start_and_end_date_of_week($args)
{
	$results=array();
	$week = json_decode(ai_mp_rp_check_isset_value($args, 'week'))->value;	
	$year = json_decode(ai_mp_rp_check_isset_value($args, 'year'))->value;	
	$format = json_decode(ai_mp_rp_check_isset_value($args, 'format'))->value;

    $results["monday"] = date($format, strtotime("{$year}-W{$week}-1")); //Returns the date of monday in week
    $results["sunday"] = date($format, strtotime("{$year}-W{$week}-7"));   //Returns the date of sunday in week
	
	return json_encode($results);
	
}

// FUNCTION TO GET WEEK NUMBER FROM DATE //

function ai_mp_rp_get_week_number_from_date($args)
{
	$results=array();
	$date = json_decode(ai_mp_rp_check_isset_value($args, 'date'))->value;		
	
	$results['week']=date('W', strtotime($date));
	
	return json_encode($results);


}

// FUNCTION TO GET ALL DATES IN CURRENT MONTH //

function ai_mp_rp_get_all_dates_in_current_month (int $year, int $month, string $format){
	
	$date = DateTime::createFromFormat("Y-n", "$year-$month");

    $all_dates = array();
    for($i=1; $i<=$date->format("t"); $i++){
        $all_dates[] = DateTime::createFromFormat("Y-n-d", "$year-$month-$i")->format($format);
    }

	return $all_dates;
 
}

// FUNCTION TO GET ALL DATES FROM NOW TO LAST 7 DAYS //

function ai_mp_rp_get_all_dates_of_past_7_days()
{
	
	$all_dates=array();
	
	for($i=0; $i<=7; $i++){

		$all_dates[]=date('Y-m-d',strtotime("- $i day"));
	
	}
	
	return $all_dates;
	
}

// FUNCTION TO GET USER ROLES //

function ai_mp_rp_get_user_role() {
	global $current_user;

	$user_roles = $current_user->roles;
	$user_role = array_shift($user_roles);

	return $user_role;
}

// FUNCTION TO GET ALL DATES BETWEEN RANGES //

function ai_mp_rp_get_all_dates_between_ranges($start, $end, $format = 'Y-m-d') { 
 
    $results = array();  
	  
	if(ai_mp_rp_check_empty_value($start)==false)
	{		
      
		// Variable that store the date interval 
		// of period 1 day 
		$interval = new DateInterval('P1D'); 
	  
		$realEnd = new DateTime($end); 
		$realEnd->add($interval); 
	  
		$period = new DatePeriod(new DateTime($start), $interval, $realEnd); 
	  
		// Use loop to store date into array 
		foreach($period as $date) {                  
			$results[] = $date->format($format);  
		} 
	
	}
  
    // Return the array elements 
    return $results; 
} 