jQuery(document).ready()
{
	if(jQuery(document).find(".ai_mp_rp_date_ranges"))
	{
		
		var from_date=jQuery(document).find(".ai_mp_rp_date_ranges_from").val();
		var from_date=(ai_mp_rp_value_empty_check(from_date)==false) ? from_date : "";	
		var to_date=jQuery(document).find(".ai_mp_rp_date_ranges_to").val();
		var to_date=(ai_mp_rp_value_empty_check(from_date)==false) ? from_date : "";	
	
						ai_mp_rp_declare_flatpicker("date",jQuery(document).find(".ai_mp_rp_date_ranges"),"",
						{	dateFormat: "Y-m-d",
							inline: false,
							minDate: from_date,
							mode:'range',
							defaultDate:[from_date,to_date],
							onChange: function(selectedDates, dateStr, instance) {
								jQuery(".ai_mp_rp_date_ranges_from").val('');
								jQuery(".ai_mp_rp_date_ranges_to").val('');								
							    if(dateStr.indexOf('to') !== -1)
								{
									var date_range = dateStr.split("to");
									var start_date=ai_mp_rp_remove_spaces_from_string(date_range[0]);
									var end_date=ai_mp_rp_remove_spaces_from_string(date_range[1]);
									jQuery(".ai_mp_rp_date_ranges_from").val(start_date);
									jQuery(".ai_mp_rp_date_ranges_to").val(end_date);									
								}
								else
								{
									jQuery(".ai_mp_rp_date_ranges_from").val(dateStr);
								}
								
								
								// CALL MAIN FUNCTION // 
								
								ai_mp_rp_manage_reporting_filters();
								
							}								
						});	
						
	}
}

// DETECT FILTER CHANGE FOR PROPERTY //

jQuery(document).on("change",".ai_mp_rp_main_actions_cnt .ai_mp_rp_filters_property_selector",function(e) {
	e.preventDefault();
	ai_mp_rp_manage_reporting_filters();
	
});


// DETECT FILTER CHANGE FOR SPACE //

jQuery(document).on("change",".ai_mp_rp_main_actions_cnt .ai_mp_rp_filters_space_selector",function(e) {
	e.preventDefault();	
	ai_mp_rp_manage_reporting_filters();	
	
});

// DETECT FILTER CHANGE FOR DURATION //

jQuery(document).on("change",".ai_mp_rp_main_actions_cnt .ai_mp_rp_filters_duration_selector",function(e) {
	e.preventDefault();	
	ai_mp_rp_manage_reporting_filters();	
	
});

// FUNCTION TO MANAGE FILTERS FOR REPORTINGS //

function ai_mp_rp_manage_reporting_filters(type)
{
	var main_action_cnt=jQuery(document).find(".ai_mp_rp_main_actions_cnt");

	
	var date_range_from=jQuery(main_action_cnt).find('.ai_mp_rp_date_ranges_from').val();	
	var date_range_to=jQuery(main_action_cnt).find('.ai_mp_rp_date_ranges_to').val();
	var duration=jQuery(main_action_cnt).find('.ai_mp_rp_filters_duration_selector option:selected').val();
	var property_id=jQuery(main_action_cnt).find('.ai_mp_rp_filters_property_selector option:selected').val();
	var space_id=jQuery(main_action_cnt).find('.ai_mp_rp_filters_space_selector option:selected').val();
	var module=jQuery(main_action_cnt).attr('module');

	
	var main_action="action=ai_mp_rp_manage_filters_cont";	
	
	var formData=main_action+"&date_range_from="+date_range_from+"&date_range_to="+date_range_to+"&duration="+duration+"&property_id="+property_id+"&space_id="+space_id+"&ajax=yes&main_action=filter&module="+module;
	
	jQuery.ajax({
		type: "post",
		dataType: "json",
		url: ai_mp_rp_custom_params.ajax_url,
		data: formData,
		success: function(data){
			if(ai_mp_rp_value_empty_check(data)==false)
			{
				var spaces=data.space_dropdown;	
				if(ai_mp_rp_value_empty_check(property_id)==false && ai_mp_rp_value_empty_check(space_id)==true)
				{
					jQuery(document).find(".ai_mp_rp_space_drop_cnt").html(spaces);
				}
				var all_data=data.data.shift();
				var all_dataset=[];
				var all_labels=[];
				
						for (const [key, value] of Object.entries(all_data)) {
							all_dataset.push(parseInt(value));
							all_labels.push(key);
						}
			
				all_dataset=all_dataset;
				all_labels=all_labels;
				myChart.data.datasets[0].data=all_dataset;
				myChart.data.labels=all_labels;
				myChart.update();
			}
		}
	});		
}