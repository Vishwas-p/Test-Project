<?php

/*********
function for enqueue js files
*************/
function ai_mp_rp_admin_scripts()
{
	wp_enqueue_style('ai_mp_rp_admin_custom_css', plugins_url('css/ai_mp_rp_admin.css', dirname(__FILE__)));
    wp_enqueue_script('ai_mp_rp_admin_common_js', plugins_url('js/ai_mp_rp_common.js', dirname(__FILE__)), '', '', true );   
	wp_enqueue_script('ai_mp_rp_admin_custom_js', plugins_url('js/ai_mp_rp_admin.js', dirname(__FILE__)), '', '', true ); 
	wp_enqueue_script('ai_mp_rp_admin_chart_js', "https://cdn.jsdelivr.net/npm/chart.js@2.8.0/dist/Chart.min.js");
	
			$params = array(
				'google_maps_key'		    => get_field("google_maps_key","option"),
				'ajax_url'                  => admin_url( 'admin-ajax.php' ),
				'theme_url'                  => get_stylesheet_directory_uri()
			);

			wp_localize_script( 'ai_mp_rp_admin_custom_js', 'ai_mp_rp_custom_params', $params );	
}

add_action('admin_enqueue_scripts', 'ai_mp_rp_admin_scripts');