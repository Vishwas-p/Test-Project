<?php
include_once("admin/admin_core.php");