<?php
/*
Plugin name:Meetingspal Customer Reports
Plugin URI:https://www.meetingspal.com/
Description:A plugin for reporting module for meetingspal customers.
Author: Paramveer Singh for meetingspal
Author URI: https://www.meetingspal.com/
Version:1.0.22
License:GPL/MIT
*/
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// PLUGIN URL PATH //
define('AIMPRPATH',plugins_url().'/ai-mp-reportings');

// PLUGIN DIR PATH //
define('AIMPRDIRPATH',plugin_dir_path( __FILE__ ));

include("core.php");

/*****activation and deactivation hooks******/
$activation_tables_creation = new ai_mp_rp_db_settings();
register_activation_hook( __FILE__, array($activation_tables_creation, 'ai_mp_rp_create_table'));
register_deactivation_hook( __FILE__, array($activation_tables_creation, 'ai_mp_rp_remove_table'));
register_activation_hook(__FILE__, 'ai_mp_rp_cron_activation');
register_deactivation_hook (__FILE__, 'ai_mp_rp_cron_deactivate');

//  ADD ACTION TO INIT ADDING MENU'S //

add_action('init','ai_mp_rp_manage_admin_menus_cont');

// FUNCION TO PROCESS ADD ACTIONS IN DB //

add_action( 'init', 'ai_mp_rp_manage_requests_cont' );

?>