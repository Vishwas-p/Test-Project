<?php

/*********
function for enqueue js files
*************/
function ai_mp_rp_admin_scripts()
{
	wp_enqueue_style('ai_mp_rp_admin_custom_css', plugins_url('css/ai_mp_rp_admin.css', dirname(__FILE__)));
    wp_enqueue_script('ai_mp_rp_admin_common_js', plugins_url('js/ai_mp_rp_common.js', dirname(__FILE__)), '', '', true );   
	wp_enqueue_script('ai_mp_rp_admin_custom_js', plugins_url('js/ai_mp_rp_admin.js', dirname(__FILE__)), '', '', true ); 
	wp_enqueue_script('ai_mp_rp_admin_chart_js', "https://cdn.jsdelivr.net/npm/chart.js@2.8.0/dist/Chart.min.js");
	wp_enqueue_script('ai_mp_rp_admin_canvas_to_pdf_js', "https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.3/jspdf.debug.js");
	
	$params = array(
				'google_maps_key'		    => get_field("google_maps_key","option"),
				'ajax_url'                  => admin_url( 'admin-ajax.php' ),
				'theme_url'                  => get_stylesheet_directory_uri()
			);

			wp_localize_script( 'ai_mp_rp_admin_custom_js', 'ai_mp_rp_custom_params', $params );
	wp_register_style( 'ai_mp_rp_poppins', 'https://fonts.googleapis.com/css?family=Poppins&display=swap' );	
	wp_register_style( 'ai_mp_rp_open_sans', 'https://fonts.googleapis.com/css?family=Open+Sans&display=swap' );
	wp_register_style( 'ai_mcn_custom_font_awesome', 'https://use.fontawesome.com/releases/v5.11.2/css/all.css' );		
	wp_register_style( 'ai_mcn_custom_font_awesome_shims', 'https://use.fontawesome.com/releases/v5.11.2/css/v4-shims.css' );	
	wp_enqueue_style( 'ai_mp_rp_poppins' );	
	wp_enqueue_style( 'ai_mp_rp_open_sans' );
	wp_enqueue_style( 'ai_mcn_custom_font_awesome' );		
	wp_enqueue_style( 'ai_mcn_custom_font_awesome_shims' );	
}

add_action('admin_enqueue_scripts', 'ai_mp_rp_admin_scripts');