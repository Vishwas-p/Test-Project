<?php

// CLASS TO OUTPUT ADMIN NOTICES //

class ai_mp_rp_admin_notices
{
    const NOTICE_FIELD = 'ai_mp_rp_admin_notices';

    public function displayAdminNotice()
    {
        $option      = get_option(self::NOTICE_FIELD);
        $message     = isset($option['message']) ? $option['message'] : false;
        $noticeLevel = ! empty($option['notice-level']) ? $option['notice-level'] : 'notice-error';

        if ($message) {
            echo "<div class='notice {$noticeLevel} is-dismissible'><p>{$message}</p></div>";
            delete_option(self::NOTICE_FIELD);
        }
    }

    public static function displayError($message)
    {
        self::updateOption($message, 'notice-error');
    }

    public static function displayWarning($message)
    {
        self::updateOption($message, 'notice-warning');
    }

    public static function displayInfo($message)
    {
        self::updateOption($message, 'notice-info');
    }

    public static function displaySuccess($message)
    {
        self::updateOption($message, 'notice-success');
    }
	
    protected static function updateOption($message, $noticeLevel) {
        update_option(self::NOTICE_FIELD, [
            'message' => $message,
            'notice-level' => $noticeLevel
        ]);
    }	
	
}

// FUNCTION TO MANAGE ADMIN NOTICES //

function ai_mp_rp_manage_notices($args)
{
	
	$type=json_decode(ai_mp_rp_check_isset_value($args,'type'))->value;
	$message=json_decode(ai_mp_rp_check_isset_value($args,'message'))->value;
	
	add_action('admin_notices', [new ai_mp_rp_admin_notices(), 'displayAdminNotice']);
		
	if($type=="success")
	{
		ai_mp_rp_admin_notices::displaySuccess(__($message));
	}
	else if($type=="error")
	{
		ai_mp_rp_admin_notices::displayError(__($message));
	}
	else if($type=="warning")
	{
		ai_mp_rp_admin_notices::displayWarning(__($message));
	}
	else if($type=="info")
	{
		ai_mp_rp_admin_notices::displayInfo(__($message));
	}

}