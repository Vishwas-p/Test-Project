<?php
// ~~ MAIN ADMIN DASHBOARD CONTROLLER ~~ // <^^!>


// FUNCTION TO MANAGE ADMIN MENU'S FOR PLUGIN //

function ai_mp_rp_manage_admin_menus_cont()
{
	
   add_action('admin_menu','ai_mp_rp_manage_admin_menus_mod');
   
}

// FUNCTION TO MANAGE GENERAL SETTINGS //

function ai_mp_rp_manage_sales_per_property_cont()
{
		$data=ai_mp_rp_manage_sales_per_property_mod(array("action"=>"view"));

		echo ai_mp_rp_manage_sales_per_property_temp(array('action'=>$action,'data'=>$data,"module"=>"properties"));			

}

// FUNCTION TO MANAGE GENERAL SETTINGS //

function ai_mp_rp_manage_sales_equipment_cont()
{
		
		$data=ai_mp_rp_manage_sales_extra_mod(array("action"=>"view","module"=>"equipments"));
	
		echo ai_mp_rp_manage_sales_extra_temp(array('action'=>'view','data'=>$data,"module"=>"equipments"));

}

function ai_mp_rp_sales_catering_settings_cont()
{
		
		$data=ai_mp_rp_manage_sales_extra_mod(array("action"=>"view","module"=>"catering"));
	
		echo ai_mp_rp_manage_sales_extra_temp(array('action'=>'view','data'=>$data,"module"=>"catering"));

}


// THE AJAX ADD ACTIONS
add_action( 'wp_ajax_ai_mp_rp_manage_filters_cont', 'ai_mp_rp_manage_filters_cont' );
add_action( 'wp_ajax_nopriv_ai_mp_rp_manage_filters_cont', 'ai_mp_rp_manage_filters_cont' ); // need this to serve non logged in users

// FUNCTION TO PROCESS AJAX REQUEST FOR FILTERS //

function ai_mp_rp_manage_filters_cont()
{
		
		$module=ai_mp_rp_check_request("module");
		$ajax=ai_mp_rp_check_request("ajax");
		$action=(ai_mp_rp_check_empty_value(ai_mp_rp_check_request("main_action"))==false) ? ai_mp_rp_check_request("main_action") : "view";
	
		if($module=="properties")
		{
			$data=ai_mp_rp_manage_sales_per_property_mod(array("action"=>$action));			
		}
		else if($module=="equipments")
		{
			$data=ai_mp_rp_manage_sales_extra_mod(array("action"=>"view","module"=>"equipments"));			
		}
		else if($module=="catering")
		{
			$data=ai_mp_rp_manage_sales_extra_mod(array("action"=>"view","module"=>"catering"));		
		}
	
		// CHECK FOR AJAX CASES AND NORMAL CASE //
		
		if($ajax=="yes")
		{
			echo $data;
			die(0);
		}	
	
}


// FUNCTION TO PROCESS ADD REQUESTS //

function ai_mp_rp_manage_requests_cont()
{
	
	if(ai_mp_rp_check_request("ai_mp_rp_example_request"))
	{
		
		
	}
	
}